// src/components/index.js
export default '../../harinistyles.css'
export { default as Header } from './Header';
export { default as Footer } from './Footer';
// Add more component exports as needed
