export const sliderData = [
    {
        image: "https://nerdtechy.com/wp-content/uploads/2021/01/Best-Nintendo-Switch-Keyboard-Mouse-Adapter.jpg",
        heading: "Hola !!!",
       
      },
    
    {
      image: "https://cdn.vox-cdn.com/thumbor/MGmzCUAVr6ShA1Uam_p6HXIK5JY=/0x0:2040x1360/2040x1360/filters:focal(1020x680:1021x681)/cdn.vox-cdn.com/uploads/chorus_asset/file/24940416/DSCF3352.jpg",
      heading: "Best Laptops",
      
    },
    {
        image: "https://allusefulinfo.com/wp-content/uploads/2013/09/windows-desktop-computer.jpg",
        heading: "DeskTops",
        
      },
    {
      image: "https://photos5.appleinsider.com/gallery/52333-104260-B49F7CF2-A60F-4F92-A972-167A4549581D-xl.jpg",
      heading: "Awesome Gadgets",
      
    },
  ];
  