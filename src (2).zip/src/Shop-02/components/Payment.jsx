import React from 'react';
import Header from './Header'

const PaymentPage = () => {
    
  return (
    <>
    <Header/>
    <div>
      <h1>Welcome to the Display Page</h1>
      <p>This is some content that you can display on your page.</p>
      <button>Click Me</button>
    </div>
    </>
  );
};
export default PaymentPage;





